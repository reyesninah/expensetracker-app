package com.ibm.training.bootcamp.casestudy.expensetracker.service;

public interface UserService {

}
