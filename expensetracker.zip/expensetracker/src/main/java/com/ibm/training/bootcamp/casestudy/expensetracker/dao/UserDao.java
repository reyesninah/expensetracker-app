package com.ibm.training.bootcamp.casestudy.expensetracker.dao;

public interface UserDao {

}
